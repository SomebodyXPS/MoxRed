package com.moxred.core;

import com.moxred.core.actions.impl.*;
import com.moxred.core.audit.AuditLogger;
import com.moxred.core.config.CoreConfig;
import com.moxred.core.execution.ActionExecutor;
import com.moxred.core.execution.ActionRegistry;
import com.moxred.core.execution.WorkflowExecutor;
import com.moxred.core.network.MoxWebSocketServer;
import com.moxred.core.security.SecurityManager;
import com.moxred.core.telemetry.TelemetryCollector;
import org.bukkit.plugin.java.JavaPlugin;

import java.net.InetSocketAddress;

/**
 * MoxRed Core Plugin - Deterministic, Secure Execution Engine for Minecraft
 */
public class MoxRedCore extends JavaPlugin {

    private CoreConfig coreConfig;
    private AuditLogger auditLogger;
    private TelemetryCollector telemetry;
    private SecurityManager securityManager;
    private ActionRegistry actionRegistry;
    private ActionExecutor actionExecutor;
    private WorkflowExecutor workflowExecutor;
    private MoxWebSocketServer webSocketServer;

    @Override
    public void onLoad() {
        getLogger().info("MoxRed Core loading...");
    }

    @Override
    public void onEnable() {
        getLogger().info("MoxRed Core enabling...");

        // Initialize configuration
        coreConfig = new CoreConfig(this);
        getLogger().info("Configuration loaded");

        // Initialize audit logger
        auditLogger = new AuditLogger(getDataFolder());
        auditLogger.log("STARTUP", "MoxRed Core starting up");

        // Initialize telemetry
        telemetry = new TelemetryCollector();

        // Initialize security manager
        securityManager = new SecurityManager(coreConfig, auditLogger);
        getLogger().info("Security manager initialized");

        // Initialize action registry and register actions
        actionRegistry = new ActionRegistry();
        registerActions();
        getLogger().info("Action registry initialized with " + actionRegistry.size() + " actions");

        // Initialize execution engine
        actionExecutor = new ActionExecutor(actionRegistry, auditLogger, telemetry);
        workflowExecutor = new WorkflowExecutor(actionRegistry);
        getLogger().info("Execution engine initialized");

        // Initialize and start WebSocket server
        try {
            InetSocketAddress address = new InetSocketAddress(coreConfig.getHost(), coreConfig.getPort());
            webSocketServer = new MoxWebSocketServer(address, this, coreConfig, securityManager,
                    actionExecutor, workflowExecutor, auditLogger, telemetry);
            webSocketServer.start();
            getLogger().info("WebSocket server started on " + coreConfig.getHost() + ":" + coreConfig.getPort());
            auditLogger.log("STARTUP", "WebSocket server started on ws://" + coreConfig.getHost() + ":" + coreConfig.getPort());
        } catch (Exception e) {
            getLogger().severe("Failed to start WebSocket server: " + e.getMessage());
            auditLogger.log("ERROR", "Failed to start WebSocket server: " + e.getMessage());
            setEnabled(false);
            return;
        }

        getLogger().info("MoxRed Core enabled successfully!");
        auditLogger.log("STARTUP", "MoxRed Core enabled successfully!");
    }

    @Override
    public void onDisable() {
        auditLogger.log("SHUTDOWN", "MoxRed Core shutting down");
        getLogger().info("MoxRed Core disabling...");

        // Stop WebSocket server
        if (webSocketServer != null) {
            try {
                webSocketServer.stop();
                getLogger().info("WebSocket server stopped");
                auditLogger.log("SHUTDOWN", "WebSocket server stopped");
            } catch (Exception e) {
                getLogger().severe("Failed to stop WebSocket server: " + e.getMessage());
                auditLogger.log("ERROR", "Failed to stop WebSocket server: " + e.getMessage());
            }
        }

        getLogger().info("MoxRed Core disabled");
    }

    /**
     * Register all available actions.
     */
    private void registerActions() {
        actionRegistry.register("BROADCAST", new BroadcastAction());
        actionRegistry.register("OP_PLAYER", new OpPlayerAction());
        actionRegistry.register("DEOP_PLAYER", new DeopPlayerAction());
        actionRegistry.register("GET_TPS", new GetTPSAction());
        actionRegistry.register("GIVE_ITEM", new GiveItemAction());
        actionRegistry.register("GIVE_RANK", new GiveRankAction());

        getLogger().info("Registered " + actionRegistry.size() + " actions");
    }

    // Getters for accessing components
    public CoreConfig getCoreConfig() {
        return coreConfig;
    }

    public AuditLogger getAuditLogger() {
        return auditLogger;
    }

    public TelemetryCollector getTelemetry() {
        return telemetry;
    }

    public SecurityManager getSecurityManager() {
        return securityManager;
    }

    public ActionRegistry getActionRegistry() {
        return actionRegistry;
    }

    public ActionExecutor getActionExecutor() {
        return actionExecutor;
    }

    public WorkflowExecutor getWorkflowExecutor() {
        return workflowExecutor;
    }

    public MoxWebSocketServer getWebSocketServer() {
        return webSocketServer;
    }
}
