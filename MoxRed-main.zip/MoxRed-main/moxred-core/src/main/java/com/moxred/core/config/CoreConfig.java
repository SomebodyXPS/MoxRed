package com.moxred.core.config;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Core configuration manager.
 */
public class CoreConfig {
    private final JavaPlugin plugin;
    private FileConfiguration config;

    // Server settings
    private String host;
    private int port;
    private boolean useSSL;

    // Security settings
    private String sharedSecret;
    private long timestampToleranceSeconds;
    private int nonceCacheSize;
    private int protocolVersion;

    // Feature flags
    private boolean enableWorkflowMode;
    private boolean enableRawConsole;

    public CoreConfig(JavaPlugin plugin) {
        this.plugin = plugin;
        loadConfig();
    }

    /**
     * Load configuration from config.yml
     */
    public void loadConfig() {
        plugin.saveDefaultConfig();
        config = plugin.getConfig();

        // Server settings
        host = config.getString("server.host", "0.0.0.0");
        port = config.getInt("server.port", 8765);
        useSSL = config.getBoolean("server.useSSL", false);

        // Security settings
        sharedSecret = config.getString("security.sharedSecret", "CHANGE_THIS_SECRET");
        timestampToleranceSeconds = config.getLong("security.timestampToleranceSeconds", 30);
        nonceCacheSize = config.getInt("security.nonceCacheSize", 5000);
        protocolVersion = config.getInt("security.protocolVersion", 1);

        // Feature settings
        enableWorkflowMode = config.getBoolean("features.enableWorkflowMode", true);
        enableRawConsole = config.getBoolean("features.enableRawConsole", false);
    }

    // Getters
    public String getHost() {
        return host;
    }

    public int getPort() {
        return port;
    }

    public boolean isUseSSL() {
        return useSSL;
    }

    public String getSharedSecret() {
        return sharedSecret;
    }

    public long getTimestampToleranceSeconds() {
        return timestampToleranceSeconds;
    }

    public int getNonceCacheSize() {
        return nonceCacheSize;
    }

    public int getProtocolVersion() {
        return protocolVersion;
    }

    public boolean isEnableWorkflowMode() {
        return enableWorkflowMode;
    }

    public boolean isEnableRawConsole() {
        return enableRawConsole;
    }
}
