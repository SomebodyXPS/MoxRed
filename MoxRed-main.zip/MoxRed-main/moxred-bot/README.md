# MoxRed Bot

**Discord AI Orchestration Layer for MoxRed**

The MoxRed Bot is a Discord bot that connects to the MoxRed Core Plugin and exposes its functionality through Discord slash commands. It handles authorization, packet signing, and communication with the core plugin.

## Architecture

```
Discord Server (Users)
    ↓
MoxRed Bot (Discord JDA)
    ↓
WebSocket Client (Signed Packets)
    ↓
MoxRed Core Plugin (Spigot/PaperMC)
    ↓
Minecraft Server (Actions)
```

## Features

- **4 Slash Commands**: `/broadcast`, `/op`, `/deop`, `/status`
- **Role-Based Authorization**: Admin role restriction
- **Packet Signing**: HMAC-SHA256 signed packets with nonce/timestamp validation
- **Async Communication**: Non-blocking WebSocket client
- **Error Handling**: User-friendly Discord embeds for all responses
- **Logging**: Audit trail of all bot actions

## Components

### Configuration (`BotConfig`)
- Loads config.yml with Discord token, roles, core server address
- Validates critical configuration on startup
- Provides type-safe configuration access

### Security (`PacketSigner`)
- Generates HMAC-SHA256 signatures for packets
- Creates unique nonces and request IDs
- Builds signed packet structures with timestamp validation support

### Network (`CorePluginClient`)
- WebSocket client extending JDA-provided base
- Async packet sending with request/response correlation
- Timeout handling and connection state management
- Supports both single actions and workflows

### Discord Integration (`DiscordEventHandler`)
- Handles slash command interactions
- Validates user authorization against admin role
- Formats responses as styled Discord embeds
- Provides human-readable uptime formatting

### Main Bot (`MoxRedBot`)
- Orchestrates bot initialization
- Manages CorePluginClient and JDA lifecycle
- Graceful shutdown with cleanup

## Setup

### 1. Prerequisites

- Java 17+ JDK
- Maven 3.9+
- Discord bot token from Discord Developer Portal
- Admin role ID from your Discord server
- MoxRed Core Plugin running and accessible

### 2. Configuration

1. Edit `config.yml`:
   ```yaml
   botToken: "YOUR_DISCORD_BOT_TOKEN"
   adminRoleId: "YOUR_ADMIN_ROLE_ID"
   coreServer:
     address: "your-server.com"
     port: 9090
   sharedSecret: "same-as-core-plugin"
   ```

2. **CRITICAL**: The `sharedSecret` must match the core plugin's `sharedSecret` exactly

3. Ensure core plugin is running and listening on configured address/port

### 3. Build

```bash
chmod +x build.sh
./build.sh
```

Output JAR: `target/moxred-bot-1.0.0.jar`

### 4. Run

```bash
java -jar target/moxred-bot-1.0.0.jar
```

The bot will:
1. Load configuration from `config.yml`
2. Connect to core plugin via WebSocket
3. Connect to Discord
4. Register slash commands
5. Listen for command interactions

## Commands

### /broadcast `<message>`
Broadcast a message to all players on the server.

**Authorization**: Admin role required
**Action**: BROADCAST

**Example**:
```
/broadcast message: Welcome to the server!
```

### /op `<player>`
Grant operator status to a player.

**Authorization**: Admin role required
**Action**: OP_PLAYER

**Example**:
```
/op player: Steve
```

### /deop `<player>`
Revoke operator status from a player.

**Authorization**: Admin role required
**Action**: DEOP_PLAYER

**Example**:
```
/deop player: Steve
```

### /status
Get current server status including player count, max players, world count, and uptime.

**Authorization**: Admin role required
**Action**: GET_TPS

**Example**:
```
/status
```

Response includes:
- Online Players
- Max Players
- Worlds
- Uptime (formatted as days/hours/minutes)

## Packet Format

All packets sent to core plugin are signed:

```json
{
  "requestId": "550e8400-e29b-41d4-a716-446655440000",
  "action": "BROADCAST",
  "executionMode": "SAFE_ACTION",
  "timestamp": 1703001234567,
  "nonce": "a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6",
  "data": {
    "message": "Hello, world!"
  },
  "signature": "abc123def456ghi789jkl012mno345pqr"
}
```

**Security**:
- `signature`: HMAC-SHA256 of entire packet (excluding signature field)
- `nonce`: Prevents replay attacks
- `timestamp`: Used by core plugin for expiry validation
- `requestId`: Correlates responses to requests

## Error Handling

All errors are presented in Discord as styled embeds:

```
Title: Broadcast Failed
Description: Player Steve not found
Color: RED
Timestamp: Current time
Footer: MoxRed Bot
```

## Logging

Check bot output for:
- Connection status
- Command execution results
- Network errors
- Authorization failures

Enable verbose logging in `config.yml`:
```yaml
verboseLogging: true
```

## Troubleshooting

### Bot won't connect to core plugin
- Verify `coreServer.address` and `coreServer.port` are correct
- Check core plugin is running: `grep "WebSocket Server" server.log`
- Verify firewall allows port 9090

### Commands not responding
- Check admin role ID is correct: `Discord > Right-click Role > Copy ID`
- Verify user has admin role assigned
- Check `sharedSecret` matches core plugin's config

### Discord bot token invalid
- Regenerate token in Discord Developer Portal
- Update `config.yml` with new token
- Restart bot

### Packet signature errors
- Verify `sharedSecret` matches core plugin **exactly**
- Check for trailing whitespace in config
- Ensure no special characters are escaped

## Development

### Project Structure

```
moxred-bot/
├── pom.xml                          # Maven configuration
├── src/main/java/com/moxred/bot/
│   ├── MoxRedBot.java              # Main bot class
│   ├── config/
│   │   └── BotConfig.java          # Configuration management
│   ├── discord/
│   │   └── DiscordEventHandler.java # Discord event handling
│   ├── network/
│   │   └── CorePluginClient.java    # WebSocket client
│   └── security/
│       └── PacketSigner.java        # Packet signing
├── src/main/resources/
│   └── config.yml                  # Default configuration
└── build.sh                        # Build script
```

### Dependencies

- **JDA 5.0.0-beta.20**: Discord bot framework
- **Java-WebSocket 1.5.4**: WebSocket client
- **Jackson 2.15.2**: JSON serialization
- **Commons-codec 1.16.0**: HMAC encoding
- **SnakeYAML 2.0**: YAML configuration

### Extending with Custom Commands

1. Add new slash command to `DiscordEventHandler.registerCommands()`
2. Add handler method: `private void handle<Action>(...)`
3. Register with core plugin as new action
4. Call `coreClient.executeAction()` with action name

Example:
```java
// In registerCommands()
Commands.slash("ban", "Ban a player")
    .addOption(OptionType.STRING, "player", "Player name", true)

// Handler
private void handleBan(SlashCommandInteractionEvent event) {
    String player = event.getOption("player").getAsString();
    Map<String, Object> data = new HashMap<>();
    data.put("playerName", player);
    
    Map<String, Object> response = coreClient.executeAction("BAN_PLAYER", data);
    // Handle response...
}
```

## Security Considerations

1. **Bot Token**: Treat as sensitive - never commit to version control
2. **Shared Secret**: Must be strong (40+ characters) and randomly generated
3. **Admin Role**: Verify only trusted users have this role
4. **Network**: Use HTTPS/WSS in production for core server communication
5. **Audit**: Review core plugin audit logs for unauthorized actions

## Limitations

- One core plugin per bot instance (extensible for multiple servers)
- Synchronous command response (JDA handles timeout)
- No persistence - in-memory state only

## Version

v1.0.0 - Initial release

## License

Part of MoxRed project
