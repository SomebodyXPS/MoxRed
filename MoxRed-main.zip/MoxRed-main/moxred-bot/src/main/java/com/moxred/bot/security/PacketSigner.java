package com.moxred.bot.security;

import org.apache.commons.codec.binary.Hex;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.*;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * Handles packet signing with HMAC-SHA256
 * Ensures packets sent to core plugin are authenticated
 */
public class PacketSigner {
    private final String sharedSecret;
    private final SecureRandom random;
    private static final String ALGORITHM = "HmacSHA256";

    public PacketSigner(String sharedSecret) {
        this.sharedSecret = sharedSecret;
        this.random = new SecureRandom();
    }

    /**
     * Generate HMAC-SHA256 signature for packet content
     */
    public String sign(String content) throws Exception {
        Mac mac = Mac.getInstance(ALGORITHM);
        SecretKeySpec key = new SecretKeySpec(
            sharedSecret.getBytes(StandardCharsets.UTF_8),
            0,
            sharedSecret.getBytes(StandardCharsets.UTF_8).length,
            ALGORITHM
        );
        mac.init(key);
        byte[] signature = mac.doFinal(content.getBytes(StandardCharsets.UTF_8));
        return Hex.encodeHexString(signature);
    }

    /**
     * Generate a unique nonce (16 bytes of random data)
     */
    public String generateNonce() {
        byte[] nonce = new byte[16];
        random.nextBytes(nonce);
        return Hex.encodeHexString(nonce);
    }

    /**
     * Generate current Unix timestamp in milliseconds
     */
    public long generateTimestamp() {
        return System.currentTimeMillis();
    }

    /**
     * Generate a unique request ID
     */
    public String generateRequestId() {
        return UUID.randomUUID().toString();
    }

    /**
     * Build and sign a complete packet
     */
    public Map<String, Object> buildSignedPacket(
            String action,
            Map<String, Object> data,
            String executionMode) throws Exception {

        Map<String, Object> packet = new LinkedHashMap<>();
        packet.put("requestId", generateRequestId());
        packet.put("action", action);
        packet.put("executionMode", executionMode);
        packet.put("timestamp", generateTimestamp());
        packet.put("nonce", generateNonce());
        packet.put("data", data);

        // Sign the entire packet structure as JSON
        String packetJson = convertToJson(packet);
        String signature = sign(packetJson);

        // Add signature to final packet
        packet.put("signature", signature);

        return packet;
    }

    /**
     * Simple JSON conversion (order preserved with LinkedHashMap)
     */
    private String convertToJson(Object obj) {
        if (obj instanceof String) {
            return "\"" + escapeJson((String) obj) + "\"";
        } else if (obj instanceof Number) {
            return obj.toString();
        } else if (obj instanceof Boolean) {
            return obj.toString();
        } else if (obj instanceof Map) {
            StringBuilder sb = new StringBuilder("{");
            Map<?, ?> map = (Map<?, ?>) obj;
            map.forEach((k, v) -> {
                if (sb.length() > 1) sb.append(",");
                sb.append("\"").append(k).append("\":");
                sb.append(convertToJson(v));
            });
            sb.append("}");
            return sb.toString();
        } else if (obj instanceof List) {
            StringBuilder sb = new StringBuilder("[");
            List<?> list = (List<?>) obj;
            list.forEach(item -> {
                if (sb.length() > 1) sb.append(",");
                sb.append(convertToJson(item));
            });
            sb.append("]");
            return sb.toString();
        }
        return "null";
    }

    /**
     * Escape JSON string characters
     */
    private String escapeJson(String str) {
        return str.replace("\\", "\\\\")
                  .replace("\"", "\\\"")
                  .replace("\n", "\\n")
                  .replace("\r", "\\r")
                  .replace("\t", "\\t");
    }
}
