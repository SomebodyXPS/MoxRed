package com.moxred.bot.discord;

import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.entities.MessageEmbed;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.events.interaction.component.ButtonInteractionEvent;
import net.dv8tion.jda.api.events.interaction.component.StringSelectInteractionEvent;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.interactions.commands.OptionType;
import net.dv8tion.jda.api.interactions.commands.build.Commands;
import net.dv8tion.jda.api.interactions.components.buttons.Button;
import net.dv8tion.jda.api.interactions.components.selections.StringSelectMenu;
import net.dv8tion.jda.api.utils.FileUpload;
import net.dv8tion.jda.api.EmbedBuilder;
import com.moxred.core.MoxRedCore;
import com.moxred.core.execution.ActionResult;
import com.moxred.bot.config.BotConfig;
import com.moxred.bot.ai.GeminiService;
import com.moxred.bot.ai.NaturalLanguageParser;

import java.awt.Color;
import java.time.Instant;
import java.util.*;

/**
 * Handles Discord events and commands
 * Routes actions directly to core plugin
 */
public class DiscordEventHandler extends ListenerAdapter {
    private final MoxRedCore corePlugin;
    private final BotConfig config;
    private final String adminRoleId;
    private final boolean verboseLogging;
    private final NaturalLanguageParser parser;
    private final boolean aiEnabled;

    public DiscordEventHandler(MoxRedCore corePlugin, BotConfig config) {
        this.corePlugin = corePlugin;
        this.config = config;
        this.adminRoleId = config.getAdminRoleId();
        this.verboseLogging = config.isVerboseLogging();
        this.aiEnabled = config.isAiEnabled();
        
        // Initialize AI if enabled
        if (aiEnabled) {
            GeminiService gemini = new GeminiService(config.getGeminiApiKey(), verboseLogging);
            this.parser = new NaturalLanguageParser(gemini, verboseLogging);
        } else {
            this.parser = null;
        }
    }

    /**
     * Register slash commands with Discord
     */
    public static void registerCommands(JDA jda) {
        jda.updateCommands()
            .addCommands(
                Commands.slash("broadcast", "Broadcast message to all players")
                    .addOption(OptionType.STRING, "message", "Message to broadcast", true),
                Commands.slash("op", "Grant operator to player")
                    .addOption(OptionType.STRING, "player", "Player name", true),
                Commands.slash("deop", "Revoke operator from player")
                    .addOption(OptionType.STRING, "player", "Player name", true),
                Commands.slash("status", "Get server status")
            )
            .queue();
    }

    /**
     * Handle natural language messages (if AI is enabled)
     */
    @Override
    public void onMessageReceived(MessageReceivedEvent event) {
        // Ignore bot messages
        if (event.getAuthor().isBot()) {
            return;
        }

        // Only process if AI is enabled and parser is ready
        if (!aiEnabled || parser == null) {
            return;
        }

        // Ignore if message is a command (starts with /)
        String content = event.getMessage().getContentRaw();
        if (content.startsWith("/")) {
            return;
        }

        // Check if bot is mentioned or message is in DM
        boolean isMention = event.getMessage().getMentions().getUsers().contains(event.getJDA().getSelfUser());
        boolean isDM = !event.isFromGuild();

        if (!isMention && !isDM) {
            return;
        }

        // Check authorization
        if (isDM && event.getMember() != null) {
            boolean hasAdminRole = event.getMember().getRoles().stream()
                .anyMatch(role -> role.getId().equals(adminRoleId));
            if (!hasAdminRole) {
                return;
            }
        }

        // Process natural language command
        String authorName = event.getAuthor().getName();
        String userId = event.getAuthor().getId();
        
        // Remove bot mention from message
        String cleanMessage = content.replaceAll("<@!?" + event.getJDA().getSelfUser().getId() + ">", "").trim();

        if (cleanMessage.isEmpty()) {
            return;
        }

        try {
            // Show typing indicator
            event.getChannel().sendTyping().queue();

            // Parse the message
            NaturalLanguageParser.CommandParseResult result = parser.parseMessage(userId, authorName, cleanMessage);

            if (!result.isSuccess()) {
                event.getChannel().sendMessageEmbeds(
                    createErrorEmbed("Could Not Understand", result.getErrorMessage())
                ).queue();
                return;
            }

            GeminiService.CommandIntent intent = result.intent;
            String action = intent.getAction();
            Map<String, Object> data = intent.getData();

            // Execute the action
            try {
                ActionResult actionResult = corePlugin.getActionExecutor().execute(action, data, corePlugin);
                boolean success = actionResult.isSuccess();
                String message = actionResult.getMessage();

                if (success) {
                    event.getChannel().sendMessageEmbeds(
                        createSuccessEmbed("Command Executed", message)
                    ).queue();
                } else {
                    event.getChannel().sendMessageEmbeds(
                        createErrorEmbed("Command Failed", message)
                    ).queue();
                }
            } catch (Exception e) {
                logError("Failed to execute action " + action, e);
                event.getChannel().sendMessageEmbeds(
                    createErrorEmbed("Execution Error", "Error: " + e.getMessage())
                ).queue();
            }

        } catch (Exception e) {
            logError("Failed to process message", e);
            event.getChannel().sendMessageEmbeds(
                createErrorEmbed("Error", "Failed to process message: " + e.getMessage())
            ).queue();
        }
    }

    @Override
    public void onSlashCommandInteraction(SlashCommandInteractionEvent event) {
        if (!isAuthorized(event)) {
            event.reply("You don't have permission to use this command").setEphemeral(true).queue();
            return;
        }

        if (event.getName().equals("broadcast")) {
            handleBroadcast(event);
        } else if (event.getName().equals("op")) {
            handleOp(event);
        } else if (event.getName().equals("deop")) {
            handleDeop(event);
        } else if (event.getName().equals("status")) {
            handleStatus(event);
        }
    }

    /**
     * Handle /broadcast command
     */
    private void handleBroadcast(SlashCommandInteractionEvent event) {
        event.deferReply().queue();

        String message = event.getOption("message").getAsString();
        Map<String, Object> data = new HashMap<>();
        data.put("message", message);

        try {
            ActionResult result = corePlugin.getActionExecutor().execute("BROADCAST", data, corePlugin);
            boolean success = result.isSuccess();

            if (success) {
                event.getHook().editOriginalEmbeds(
                    createSuccessEmbed("Broadcast Sent", "Message broadcast to all players:\n" + message)
                ).queue();
            } else {
                String error = result.getMessage();
                event.getHook().editOriginalEmbeds(
                    createErrorEmbed("Broadcast Failed", error)
                ).queue();
            }
        } catch (Exception e) {
            event.getHook().editOriginalEmbeds(
                createErrorEmbed("Error", "Failed to broadcast: " + e.getMessage())
            ).queue();
            logError("Broadcast failed", e);
        }
    }

    /**
     * Handle /op command
     */
    private void handleOp(SlashCommandInteractionEvent event) {
        event.deferReply().queue();

        String player = event.getOption("player").getAsString();
        Map<String, Object> data = new HashMap<>();
        data.put("playerName", player);

        try {
            ActionResult result = corePlugin.getActionExecutor().execute("OP_PLAYER", data, corePlugin);
            boolean success = result.isSuccess();

            if (success) {
                event.getHook().editOriginalEmbeds(
                    createSuccessEmbed("Player Opped", "Granted operator status to: " + player)
                ).queue();
            } else {
                String error = result.getMessage();
                event.getHook().editOriginalEmbeds(
                    createErrorEmbed("Op Failed", error)
                ).queue();
            }
        } catch (Exception e) {
            event.getHook().editOriginalEmbeds(
                createErrorEmbed("Error", "Failed to op player: " + e.getMessage())
            ).queue();
            logError("Op failed", e);
        }
    }

    /**
     * Handle /deop command
     */
    private void handleDeop(SlashCommandInteractionEvent event) {
        event.deferReply().queue();

        String player = event.getOption("player").getAsString();
        Map<String, Object> data = new HashMap<>();
        data.put("playerName", player);

        try {
            ActionResult result = corePlugin.getActionExecutor().execute("DEOP_PLAYER", data, corePlugin);
            boolean success = result.isSuccess();

            if (success) {
                event.getHook().editOriginalEmbeds(
                    createSuccessEmbed("Player Deopped", "Revoked operator status from: " + player)
                ).queue();
            } else {
                String error = result.getMessage();
                event.getHook().editOriginalEmbeds(
                    createErrorEmbed("Deop Failed", error)
                ).queue();
            }
        } catch (Exception e) {
            event.getHook().editOriginalEmbeds(
                createErrorEmbed("Error", "Failed to deop player: " + e.getMessage())
            ).queue();
            logError("Deop failed", e);
        }
    }

    /**
     * Handle /status command
     */
    private void handleStatus(SlashCommandInteractionEvent event) {
        event.deferReply().queue();

        try {
            ActionResult result = corePlugin.getActionExecutor().execute("GET_TPS", new HashMap<>(), corePlugin);
            boolean success = result.isSuccess();

            if (success) {
                Map<String, Object> data = (Map<String, Object>) result.getData().getOrDefault("data", new HashMap<>());
                
                // Handle both Integer and Long types for numeric fields
                long uptimeMs = 0;
                Object uptimeObj = data.getOrDefault("uptime_ms", 0);
                if (uptimeObj instanceof Long) {
                    uptimeMs = (Long) uptimeObj;
                } else if (uptimeObj instanceof Integer) {
                    uptimeMs = ((Integer) uptimeObj).longValue();
                }
                
                EmbedBuilder embed = new EmbedBuilder()
                    .setTitle("Server Status")
                    .setColor(Color.GREEN)
                    .addField("Online Players", String.valueOf(data.getOrDefault("players_online", 0)), true)
                    .addField("Max Players", String.valueOf(data.getOrDefault("max_players", 0)), true)
                    .addField("Worlds", String.valueOf(data.getOrDefault("worlds", 0)), true)
                    .addField("Uptime", formatUptime(uptimeMs), true)
                    .setTimestamp(Instant.now())
                    .setFooter("MoxRed Bot");

                event.getHook().editOriginalEmbeds(embed.build()).queue();
            } else {
                String error = result.getMessage();
                event.getHook().editOriginalEmbeds(
                    createErrorEmbed("Status Check Failed", error)
                ).queue();
            }
        } catch (Exception e) {
            event.getHook().editOriginalEmbeds(
                createErrorEmbed("Error", "Failed to get status: " + e.getMessage())
            ).queue();
            logError("Status check failed", e);
        }
    }

    /**
     * Check if user has admin role
     */
    private boolean isAuthorized(SlashCommandInteractionEvent event) {
        if (event.getMember() == null) return false;
        return event.getMember().getRoles().stream()
            .anyMatch(role -> role.getId().equals(adminRoleId));
    }

    /**
     * Create success embed
     */
    private MessageEmbed createSuccessEmbed(String title, String description) {
        return new EmbedBuilder()
            .setTitle(title)
            .setDescription(description)
            .setColor(Color.GREEN)
            .setTimestamp(Instant.now())
            .setFooter("MoxRed Bot")
            .build();
    }

    /**
     * Create error embed
     */
    private MessageEmbed createErrorEmbed(String title, String description) {
        return new EmbedBuilder()
            .setTitle(title)
            .setDescription(description)
            .setColor(Color.RED)
            .setTimestamp(Instant.now())
            .setFooter("MoxRed Bot")
            .build();
    }

    /**
     * Format milliseconds to human-readable uptime
     */
    private String formatUptime(long ms) {
        long seconds = ms / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        long days = hours / 24;

        if (days > 0) {
            return days + "d " + (hours % 24) + "h";
        } else if (hours > 0) {
            return hours + "h " + (minutes % 60) + "m";
        } else if (minutes > 0) {
            return minutes + "m " + (seconds % 60) + "s";
        } else {
            return seconds + "s";
        }
    }

    /**
     * Log error message
     */
    private void logError(String context, Exception e) {
        System.err.println("[DiscordEventHandler] " + context + ": " + e.getMessage());
        if (verboseLogging) {
            e.printStackTrace();
        }
    }
}
