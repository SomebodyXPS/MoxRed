package com.moxred.bot.network;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.moxred.bot.config.BotConfig;
import com.moxred.bot.security.PacketSigner;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;
import java.util.*;
import java.util.concurrent.*;

/**
 * WebSocket client for communicating with MoxRed Core Plugin
 * Handles connection, packet sending, and response receiving
 */
public class CorePluginClient extends WebSocketClient {
    private final PacketSigner signer;
    private final ObjectMapper mapper;
    private final int timeoutMs;
    private final ConcurrentHashMap<String, CompletableFuture<Map<String, Object>>> pendingRequests;
    private boolean connected = false;
    private final boolean verboseLogging;

    public CorePluginClient(BotConfig config) {
        super(URI.create(config.getCoreServerUrl()));
        this.signer = new PacketSigner(config.getSharedSecret());
        this.mapper = new ObjectMapper();
        this.timeoutMs = (int) config.getIdleTimeoutMs();
        this.pendingRequests = new ConcurrentHashMap<>();
        this.verboseLogging = config.isVerboseLogging();
        this.setConnectionLostTimeout(timeoutMs / 1000);
    }

    @Override
    public void onOpen(ServerHandshake handshakedata) {
        connected = true;
        log("Connected to core plugin");
    }

    @Override
    public void onMessage(String message) {
        try {
            if (verboseLogging) log("Received: " + message);

            Map<String, Object> response = mapper.readValue(message, Map.class);
            String requestId = (String) response.get("requestId");

            if (requestId != null && pendingRequests.containsKey(requestId)) {
                CompletableFuture<Map<String, Object>> future = pendingRequests.remove(requestId);
                future.complete(response);
            }
        } catch (Exception e) {
            log("Error processing message: " + e.getMessage());
        }
    }

    @Override
    public void onClose(int code, String reason, boolean remote) {
        connected = false;
        log("Disconnected from core plugin: " + reason);
    }

    @Override
    public void onError(Exception ex) {
        log("WebSocket error: " + ex.getMessage());
        connected = false;
    }

    /**
     * Send an action packet to core plugin and wait for response
     */
    public Map<String, Object> executeAction(String action, Map<String, Object> data) throws Exception {
        if (!connected) {
            throw new RuntimeException("Not connected to core plugin");
        }

        // Build signed packet
        Map<String, Object> packet = signer.buildSignedPacket(action, data, "SAFE_ACTION");
        String requestId = (String) packet.get("requestId");

        // Set up response future with timeout
        CompletableFuture<Map<String, Object>> responseFuture = new CompletableFuture<>();
        pendingRequests.put(requestId, responseFuture);

        try {
            // Send packet as JSON
            String packetJson = mapper.writeValueAsString(packet);
            if (verboseLogging) log("Sending: " + packetJson);
            this.send(packetJson);

            // Wait for response with timeout
            return responseFuture.get(timeoutMs, TimeUnit.MILLISECONDS);
        } catch (TimeoutException e) {
            pendingRequests.remove(requestId);
            throw new RuntimeException("Core plugin response timeout after " + timeoutMs + "ms");
        }
    }

    /**
     * Execute a workflow (multiple chained actions)
     */
    public Map<String, Object> executeWorkflow(List<String> actions, List<Map<String, Object>> dataList) throws Exception {
        if (!connected) {
            throw new RuntimeException("Not connected to core plugin");
        }

        Map<String, Object> workflowData = new HashMap<>();
        workflowData.put("actions", actions);
        workflowData.put("data", dataList);

        Map<String, Object> packet = signer.buildSignedPacket("WORKFLOW", workflowData, "WORKFLOW");
        String requestId = (String) packet.get("requestId");

        CompletableFuture<Map<String, Object>> responseFuture = new CompletableFuture<>();
        pendingRequests.put(requestId, responseFuture);

        try {
            String packetJson = mapper.writeValueAsString(packet);
            if (verboseLogging) log("Sending workflow: " + packetJson);
            this.send(packetJson);

            return responseFuture.get(timeoutMs, TimeUnit.MILLISECONDS);
        } catch (TimeoutException e) {
            pendingRequests.remove(requestId);
            throw new RuntimeException("Workflow response timeout after " + timeoutMs + "ms");
        }
    }

    /**
     * Check if client is connected
     */
    public boolean isConnected() {
        return connected && super.isOpen();
    }

    /**
     * Shutdown client and cleanup
     */
    public void shutdown() {
        if (isConnected()) {
            this.close();
        }
        // Complete any pending futures
        pendingRequests.forEach((id, future) -> 
            future.completeExceptionally(new RuntimeException("Client shutting down"))
        );
        pendingRequests.clear();
    }

    /**
     * Log message with timestamp
     */
    private void log(String message) {
        System.out.println("[CorePluginClient] " + message);
    }
}
